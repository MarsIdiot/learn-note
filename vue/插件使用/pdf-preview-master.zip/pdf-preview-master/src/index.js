import pdfJS from 'pdfjs-dist'
import pdfPreview from './components/PdfPreview.vue'

export default pdfPreview
